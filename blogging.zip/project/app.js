// Data management
const store = {
    users: JSON.parse(localStorage.getItem('users')) || [],
    posts: JSON.parse(localStorage.getItem('posts')) || [],
    currentUser: JSON.parse(localStorage.getItem('currentUser')) || null
};

// Auth functions
function handleLogin(event) {
    event.preventDefault();
    const email = event.target[0].value;
    const password = event.target[1].value;

    const user = store.users.find(u => u.email === email && u.password === password);
    if (user) {
        store.currentUser = user;
        localStorage.setItem('currentUser', JSON.stringify(user));
        updateUI();
        showBlogPosts();
    } else {
        alert('Invalid credentials');
    }
}

function handleRegister(event) {
    event.preventDefault();
    const username = event.target[0].value;
    const email = event.target[1].value;
    const password = event.target[2].value;

    if (store.users.some(u => u.email === email)) {
        alert('Email already registered');
        return;
    }

    const newUser = {
        id: Date.now().toString(),
        username,
        email,
        password
    };

    store.users.push(newUser);
    localStorage.setItem('users', JSON.stringify(store.users));
    store.currentUser = newUser;
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    updateUI();
    showBlogPosts();
}

function logout() {
    store.currentUser = null;
    localStorage.removeItem('currentUser');
    updateUI();
}

// Blog post functions
function handleNewPost(event) {
    event.preventDefault();
    const title = document.getElementById('post-title').value;
    const content = document.getElementById('post-content').value;

    const newPost = {
        id: Date.now().toString(),
        title,
        content,
        author: store.currentUser.username,
        authorId: store.currentUser.id,
        date: new Date().toISOString(),
        comments: []
    };

    store.posts.unshift(newPost);
    localStorage.setItem('posts', JSON.stringify(store.posts));
    event.target.reset();
    showBlogPosts();
}

function deletePost(postId) {
    store.posts = store.posts.filter(post => post.id !== postId);
    localStorage.setItem('posts', JSON.stringify(store.posts));
    showBlogPosts();
}

function addComment(postId, comment) {
    const post = store.posts.find(p => p.id === postId);
    if (post) {
        post.comments.push({
            id: Date.now().toString(),
            content: comment,
            author: store.currentUser.username,
            date: new Date().toISOString()
        });
        localStorage.setItem('posts', JSON.stringify(store.posts));
        showBlogPosts();
    }
}

// UI functions
function updateUI() {
    const navLinks = document.getElementById('nav-links');
    const authForms = document.getElementById('auth-forms');
    const blogPosts = document.getElementById('blog-posts');

    if (store.currentUser) {
        navLinks.innerHTML = `
            <span>Welcome, ${store.currentUser.username}</span>
            <button onclick="logout()" class="nav-link">Logout</button>
        `;
        authForms.classList.add('hidden');
        blogPosts.classList.remove('hidden');
    } else {
        navLinks.innerHTML = `
            <button id="loginBtn" class="nav-link">Login</button>
            <button id="registerBtn" class="nav-link">Register</button>
        `;
        authForms.classList.remove('hidden');
        blogPosts.classList.add('hidden');
        setupAuthFormToggle();
    }
}

function setupAuthFormToggle() {
    const loginBtn = document.getElementById('loginBtn');
    const registerBtn = document.getElementById('registerBtn');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');

    loginBtn.addEventListener('click', () => {
        loginForm.classList.remove('hidden');
        registerForm.classList.add('hidden');
    });

    registerBtn.addEventListener('click', () => {
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
    });
}

function showBlogPosts() {
    const postsContainer = document.getElementById('posts-container');
    const newPostForm = document.getElementById('new-post-form');
    newPostForm.classList.add('hidden');

    postsContainer.innerHTML = store.posts.map(post => `
        <div class="post-card">
            <div class="post-header">
                <h3 class="post-title">${post.title}</h3>
                <div class="post-meta">
                    By ${post.author} on ${new Date(post.date).toLocaleDateString()}
                </div>
            </div>
            <div class="post-content">${post.content}</div>
            ${store.currentUser && store.currentUser.id === post.authorId ? `
                <div class="post-actions">
                    <button onclick="deletePost('${post.id}')">Delete</button>
                </div>
            ` : ''}
            <div class="comments-section">
                <h4>Comments (${post.comments.length})</h4>
                ${post.comments.map(comment => `
                    <div class="comment">
                        <div class="post-meta">
                            ${comment.author} - ${new Date(comment.date).toLocaleDateString()}
                        </div>
                        <div>${comment.content}</div>
                    </div>
                `).join('')}
                ${store.currentUser ? `
                    <form onsubmit="event.preventDefault(); addComment('${post.id}', this.comment.value); this.reset()">
                        <input name="comment" placeholder="Add a comment..." required>
                        <button type="submit">Comment</button>
                    </form>
                ` : ''}
            </div>
        </div>
    `).join('');
}

function showNewPostForm() {
    document.getElementById('new-post-form').classList.remove('hidden');
    document.getElementById('blog-posts').classList.add('hidden');
}

function cancelNewPost() {
    document.getElementById('new-post-form').classList.add('hidden');
    document.getElementById('blog-posts').classList.remove('hidden');
}

// Event Listeners
document.getElementById('newPostBtn').addEventListener('click', showNewPostForm);

// Initialize UI
updateUI();